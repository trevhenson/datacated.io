Feature request or idea? Consider opening an
[API review](https://github.com/stripe/react-stripe-elements/tree/master/.github/API_REVIEW.md)!

<!--
react-stripe-elements is a thin wrapper around Stripe.js and Stripe
Elements for React. Please only file issues here that you believe
represent bugs with react-stripe-elements, not Stripe.js itself.

If you're having general trouble with Stripe.js or your Stripe integration,
please reach out to us using the form at https://support.stripe.com/email or
come chat with us at #stripe on freenode. We're very proud of our level of
service, and we're more than happy to help you out with your integration.
-->

### Summary

<!-- For bug reports, include detailed steps to reproduce or a minimal reproduction of the issue (You can even start from this JSFiddle: https://jsfiddle.net/g9rm5qkt/) -->

### Other information

<!-- For visual issues, include screenshots! -->

<!-- Is this specific to one browser, or does it happen in multiple browsers? -->
